<script src="<?php echo e(url('js/MapView.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\WebDesigner\Desktop\mapview\resources\views/template/foot.blade.php ENDPATH**/ ?>