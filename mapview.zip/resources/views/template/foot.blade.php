<script src="{{url('js/MapView.js')}}"></script>

</body>
</html>