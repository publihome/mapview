@include('template.header')
@include('template.navbar')

{{-- {{var_dump($data)}} --}}
{{-- <div class="col-md-4 col-xs-6 form-input">
        <select name="medio" id="medio" class="form-control">
            <option value="" selected></option>
            <option value="espectaculares">Espectaculares</option>
            <option value="vallas">Vallas fijas</option>
        </select>
    </div> --}}

<div class="map" id="map"></div>
    






@include('template.modal')


@include('template.foot')