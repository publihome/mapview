<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class MapViewModel extends Model
{
    use HasFactory;

    public function getEspectaculares(){
        $espectaculares = DB::table('espectaculares')
                                ->join('medios', 'medios.id', "=" ,'espectaculares.id_medio')
                                ->get();
        return $espectaculares;
    }

    public function getVallas(){
        $vallas = DB::table('vallas_fijas')
                                ->join('medios', 'medios.id', "=" ,'vallas_fijas.id_medio')
                                ->get();
        return $vallas;
    }
    
}
